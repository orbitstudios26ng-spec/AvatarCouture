import React from 'react';

interface AvatarProps {
  skinTone: string;
  hairColor: string;
  hairStyle: string;
  outfit: {
    top: string;
    bottom: string;
    shoes: string;
    accessories: string[];
  };
}

export function RealisticAvatar({ skinTone, hairColor, hairStyle, outfit }: AvatarProps) {
  // Skin tone colors with realistic gradients
  const skinTones: Record<string, { base: string; shadow: string; highlight: string }> = {
    light: { base: '#ffd6c8', shadow: '#f0b4a3', highlight: '#ffe8dc' },
    medium: { base: '#d4a373', shadow: '#b8885a', highlight: '#e6c19a' },
    tan: { base: '#c68b59', shadow: '#a87244', highlight: '#dda87a' },
    dark: { base: '#8b5a3c', shadow: '#6d4428', highlight: '#a67152' },
    deep: { base: '#5c3d2e', shadow: '#442b1f', highlight: '#75503e' },
  };

  // Hair color mapping
  const hairColors: Record<string, string> = {
    black: '#1a1a1a',
    brown: '#5c4033',
    blonde: '#f4d03f',
    red: '#c23b22',
    gray: '#95a5a6',
  };

  const skin = skinTones[skinTone] || skinTones.light;
  const hair = hairColors[hairColor] || hairColors.brown;

  // Render hair based on style
  const renderHair = () => {
    if (hairStyle === 'short') {
      return (
        <g id="hair-short">
          <defs>
            <linearGradient id="hairGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={hair} stopOpacity="1" />
              <stop offset="100%" stopColor={hair} stopOpacity="0.7" />
            </linearGradient>
          </defs>
          <ellipse cx="200" cy="70" rx="85" ry="45" fill="url(#hairGradient)" />
          <path d="M 115 70 Q 115 40 145 35 Q 175 30 200 28 Q 225 30 255 35 Q 285 40 285 70" fill={hair} />
          {/* Hair strands */}
          <path d="M 180 30 Q 182 28 184 30" stroke={hair} strokeWidth="1" opacity="0.5" />
          <path d="M 200 28 Q 202 26 204 28" stroke={hair} strokeWidth="1" opacity="0.5" />
          <path d="M 220 30 Q 222 28 224 30" stroke={hair} strokeWidth="1" opacity="0.5" />
          {/* Shine highlight */}
          <ellipse cx="220" cy="55" rx="20" ry="12" fill="white" opacity="0.2" />
        </g>
      );
    } else if (hairStyle === 'long') {
      return (
        <g id="hair-long">
          <defs>
            <linearGradient id="hairGradientLong" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={hair} stopOpacity="1" />
              <stop offset="100%" stopColor={hair} stopOpacity="0.8" />
            </linearGradient>
          </defs>
          <ellipse cx="200" cy="70" rx="85" ry="45" fill="url(#hairGradientLong)" />
          <path d="M 115 70 Q 100 150 110 220" fill={hair} stroke={hair} strokeWidth="20" />
          <path d="M 285 70 Q 300 150 290 220" fill={hair} stroke={hair} strokeWidth="20" />
          <path d="M 200 80 Q 200 150 200 230" fill={hair} stroke={hair} strokeWidth="15" />
          {/* Hair strands for texture */}
          <path d="M 120 100 Q 105 160 112 210" stroke={hair} strokeWidth="2" opacity="0.6" />
          <path d="M 280 100 Q 295 160 288 210" stroke={hair} strokeWidth="2" opacity="0.6" />
          {/* Shine highlight */}
          <ellipse cx="220" cy="55" rx="25" ry="15" fill="white" opacity="0.2" />
        </g>
      );
    } else if (hairStyle === 'curly') {
      return (
        <g id="hair-curly">
          <defs>
            <radialGradient id="curlGradient">
              <stop offset="0%" stopColor={hair} stopOpacity="1" />
              <stop offset="100%" stopColor={hair} stopOpacity="0.7" />
            </radialGradient>
          </defs>
          {/* Voluminous curly hair */}
          <circle cx="150" cy="60" r="35" fill="url(#curlGradient)" />
          <circle cx="180" cy="50" r="32" fill="url(#curlGradient)" />
          <circle cx="200" cy="45" r="35" fill="url(#curlGradient)" />
          <circle cx="220" cy="50" r="32" fill="url(#curlGradient)" />
          <circle cx="250" cy="60" r="35" fill="url(#curlGradient)" />
          <circle cx="130" cy="80" r="28" fill="url(#curlGradient)" />
          <circle cx="270" cy="80" r="28" fill="url(#curlGradient)" />
          <circle cx="170" cy="75" r="30" fill="url(#curlGradient)" />
          <circle cx="230" cy="75" r="30" fill="url(#curlGradient)" />
          {/* More curls for volume */}
          <circle cx="200" cy="70" r="28" fill="url(#curlGradient)" />
          <circle cx="155" cy="90" r="25" fill="url(#curlGradient)" />
          <circle cx="245" cy="90" r="25" fill="url(#curlGradient)" />
          {/* Highlight */}
          <circle cx="210" cy="50" r="15" fill="white" opacity="0.25" />
        </g>
      );
    }
    return null;
  };

  // Render clothing
  const renderTop = () => {
    if (outfit.top === 't-shirt') {
      return (
        <g id="tshirt">
          <defs>
            <linearGradient id="shirtGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3498db" stopOpacity="0.8" />
              <stop offset="50%" stopColor="#3498db" stopOpacity="1" />
              <stop offset="100%" stopColor="#2980b9" stopOpacity="0.9" />
            </linearGradient>
          </defs>
          {/* Shoulders and sleeves */}
          <path d="M 140 180 L 120 200 L 130 240 L 150 220 Z" fill="url(#shirtGradient)" />
          <path d="M 260 180 L 280 200 L 270 240 L 250 220 Z" fill="url(#shirtGradient)" />
          {/* Main body */}
          <rect x="140" y="180" width="120" height="120" rx="5" fill="url(#shirtGradient)" />
          {/* Neckline */}
          <ellipse cx="200" cy="180" rx="25" ry="15" fill={skin.base} />
          {/* Fabric folds */}
          <line x1="180" y1="200" x2="180" y2="280" stroke="#2980b9" strokeWidth="1" opacity="0.3" />
          <line x1="200" y1="200" x2="200" y2="290" stroke="#5dade2" strokeWidth="1" opacity="0.3" />
          <line x1="220" y1="200" x2="220" y2="280" stroke="#2980b9" strokeWidth="1" opacity="0.3" />
          {/* Highlight on shoulder */}
          <path d="M 145 185 Q 160 190 170 185" stroke="white" strokeWidth="2" opacity="0.4" />
        </g>
      );
    } else if (outfit.top === 'hoodie') {
      return (
        <g id="hoodie">
          <defs>
            <linearGradient id="hoodieGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#7f8c8d" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#95a5a6" stopOpacity="1" />
              <stop offset="100%" stopColor="#7f8c8d" stopOpacity="0.9" />
            </linearGradient>
          </defs>
          {/* Hood */}
          <path d="M 160 160 Q 200 140 240 160 L 240 180 L 160 180 Z" fill="url(#hoodieGradient)" />
          {/* Shoulders */}
          <path d="M 130 180 L 110 200 L 120 250 L 145 230 Z" fill="url(#hoodieGradient)" />
          <path d="M 270 180 L 290 200 L 280 250 L 255 230 Z" fill="url(#hoodieGradient)" />
          {/* Main body */}
          <rect x="130" y="180" width="140" height="130" rx="5" fill="url(#hoodieGradient)" />
          {/* Kangaroo pocket */}
          <rect x="165" y="240" width="70" height="45" rx="8" fill="#6c7a7b" opacity="0.6" />
          <line x1="200" y1="240" x2="200" y2="285" stroke="#5d6d6e" strokeWidth="1" />
          {/* Drawstring */}
          <circle cx="190" cy="185" r="3" fill="#34495e" />
          <circle cx="210" cy="185" r="3" fill="#34495e" />
          <path d="M 190 185 Q 195 190 200 188" stroke="#34495e" strokeWidth="2" fill="none" />
          <path d="M 210 185 Q 205 190 200 188" stroke="#34495e" strokeWidth="2" fill="none" />
          {/* Zipper */}
          <line x1="200" y1="185" x2="200" y2="300" stroke="#bdc3c7" strokeWidth="3" />
          <rect x="198" y="190" width="4" height="8" fill="#34495e" />
          <rect x="198" y="210" width="4" height="8" fill="#34495e" />
          <rect x="198" y="230" width="4" height="8" fill="#34495e" />
        </g>
      );
    } else if (outfit.top === 'dress') {
      return (
        <g id="dress">
          <defs>
            <linearGradient id="dressGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#e74c3c" stopOpacity="1" />
              <stop offset="100%" stopColor="#c0392b" stopOpacity="0.9" />
            </linearGradient>
          </defs>
          {/* Straps */}
          <rect x="160" y="170" width="15" height="30" fill="url(#dressGradient)" />
          <rect x="225" y="170" width="15" height="30" fill="url(#dressGradient)" />
          {/* Bodice */}
          <path d="M 160 200 L 240 200 L 245 240 L 155 240 Z" fill="url(#dressGradient)" />
          {/* Skirt */}
          <path d="M 155 240 L 145 350 L 255 350 L 245 240 Z" fill="url(#dressGradient)" />
          {/* Fabric folds */}
          <line x1="175" y1="250" x2="170" y2="340" stroke="#c0392b" strokeWidth="1.5" opacity="0.4" />
          <line x1="200" y1="250" x2="200" y2="350" stroke="#e8695f" strokeWidth="1.5" opacity="0.3" />
          <line x1="225" y1="250" x2="230" y2="340" stroke="#c0392b" strokeWidth="1.5" opacity="0.4" />
          {/* Belt/waistline */}
          <rect x="155" y="235" width="90" height="8" fill="#8e44ad" />
        </g>
      );
    }
    return null;
  };

  const renderBottom = () => {
    if (outfit.bottom === 'jeans') {
      return (
        <g id="jeans">
          <defs>
            <linearGradient id="jeansGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#34495e" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#5d6d7e" stopOpacity="1" />
              <stop offset="100%" stopColor="#34495e" stopOpacity="0.9" />
            </linearGradient>
          </defs>
          {/* Left leg */}
          <path d="M 175 300 L 170 400 L 190 400 L 195 300 Z" fill="url(#jeansGradient)" />
          {/* Right leg */}
          <path d="M 205 300 L 210 400 L 230 400 L 225 300 Z" fill="url(#jeansGradient)" />
          {/* Waistband */}
          <rect x="170" y="295" width="60" height="8" fill="#2c3e50" />
          {/* Belt loops */}
          <rect x="180" y="295" width="3" height="8" fill="#d4af37" opacity="0.7" />
          <rect x="198" y="295" width="3" height="8" fill="#d4af37" opacity="0.7" />
          <rect x="218" y="295" width="3" height="8" fill="#d4af37" opacity="0.7" />
          {/* Pockets */}
          <path d="M 178 310 Q 185 315 178 325" stroke="#2c3e50" strokeWidth="2" fill="none" />
          <path d="M 222 310 Q 215 315 222 325" stroke="#2c3e50" strokeWidth="2" fill="none" />
          {/* Seam lines */}
          <line x1="183" y1="305" x2="178" y2="395" stroke="#708090" strokeWidth="1.5" opacity="0.5" />
          <line x1="217" y1="305" x2="222" y2="395" stroke="#708090" strokeWidth="1.5" opacity="0.5" />
          {/* Stitching detail */}
          <path d="M 175 305 Q 177 305 179 305" stroke="#d4af37" strokeWidth="0.5" opacity="0.8" />
          <path d="M 221 305 Q 223 305 225 305" stroke="#d4af37" strokeWidth="0.5" opacity="0.8" />
        </g>
      );
    } else if (outfit.bottom === 'skirt') {
      return (
        <g id="skirt">
          <defs>
            <linearGradient id="skirtGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#f39c12" stopOpacity="1" />
              <stop offset="100%" stopColor="#e67e22" stopOpacity="0.9" />
            </linearGradient>
          </defs>
          <path d="M 165 300 L 145 370 L 255 370 L 235 300 Z" fill="url(#skirtGradient)" />
          {/* Pleats */}
          <line x1="180" y1="305" x2="165" y2="365" stroke="#d68910" strokeWidth="2" opacity="0.5" />
          <line x1="200" y1="305" x2="200" y2="370" stroke="#d68910" strokeWidth="2" opacity="0.5" />
          <line x1="220" y1="305" x2="235" y2="365" stroke="#d68910" strokeWidth="2" opacity="0.5" />
          {/* Waistband */}
          <rect x="165" y="295" width="70" height="8" fill="#c0751b" />
        </g>
      );
    } else if (outfit.bottom === 'shorts') {
      return (
        <g id="shorts">
          <defs>
            <linearGradient id="shortsGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#27ae60" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#2ecc71" stopOpacity="1" />
              <stop offset="100%" stopColor="#27ae60" stopOpacity="0.9" />
            </linearGradient>
          </defs>
          {/* Left leg */}
          <path d="M 175 300 L 168 340 L 188 340 L 195 300 Z" fill="url(#shortsGradient)" />
          {/* Right leg */}
          <path d="M 205 300 L 212 340 L 232 340 L 225 300 Z" fill="url(#shortsGradient)" />
          {/* Waistband */}
          <rect x="170" y="295" width="60" height="8" fill="#1e8449" />
          {/* Pockets */}
          <path d="M 178 305 Q 183 308 178 315" stroke="#1e8449" strokeWidth="1.5" fill="none" />
          <path d="M 222 305 Q 217 308 222 315" stroke="#1e8449" strokeWidth="1.5" fill="none" />
        </g>
      );
    }
    return null;
  };

  const renderShoes = () => {
    if (outfit.shoes === 'sneakers') {
      return (
        <g id="sneakers">
          {/* Left sneaker */}
          <ellipse cx="180" cy="410" rx="18" ry="8" fill="#2c3e50" />
          <rect x="162" y="400" width="36" height="12" rx="3" fill="#ecf0f1" />
          <path d="M 165 402 L 195 402" stroke="#bdc3c7" strokeWidth="1" />
          <path d="M 165 406 L 195 406" stroke="#bdc3c7" strokeWidth="1" />
          {/* Laces */}
          <circle cx="172" cy="404" r="1.5" fill="#34495e" />
          <circle cx="180" cy="404" r="1.5" fill="#34495e" />
          <circle cx="188" cy="404" r="1.5" fill="#34495e" />
          
          {/* Right sneaker */}
          <ellipse cx="220" cy="410" rx="18" ry="8" fill="#2c3e50" />
          <rect x="202" y="400" width="36" height="12" rx="3" fill="#ecf0f1" />
          <path d="M 205 402 L 235 402" stroke="#bdc3c7" strokeWidth="1" />
          <path d="M 205 406 L 235 406" stroke="#bdc3c7" strokeWidth="1" />
          {/* Laces */}
          <circle cx="212" cy="404" r="1.5" fill="#34495e" />
          <circle cx="220" cy="404" r="1.5" fill="#34495e" />
          <circle cx="228" cy="404" r="1.5" fill="#34495e" />
        </g>
      );
    } else if (outfit.shoes === 'boots') {
      return (
        <g id="boots">
          <defs>
            <linearGradient id="bootGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#8b4513" stopOpacity="1" />
              <stop offset="100%" stopColor="#5d2e0f" stopOpacity="1" />
            </linearGradient>
          </defs>
          {/* Left boot */}
          <rect x="165" y="370" width="30" height="35" rx="2" fill="url(#bootGradient)" />
          <ellipse cx="180" cy="407" rx="17" ry="6" fill="#5d2e0f" />
          <rect x="168" y="385" width="24" height="3" fill="#654321" />
          <circle cx="172" cy="386.5" r="1.5" fill="#d4af37" />
          <circle cx="188" cy="386.5" r="1.5" fill="#d4af37" />
          {/* Shine effect */}
          <path d="M 170 375 Q 175 378 180 375" stroke="white" strokeWidth="1.5" opacity="0.4" />
          
          {/* Right boot */}
          <rect x="205" y="370" width="30" height="35" rx="2" fill="url(#bootGradient)" />
          <ellipse cx="220" cy="407" rx="17" ry="6" fill="#5d2e0f" />
          <rect x="208" y="385" width="24" height="3" fill="#654321" />
          <circle cx="212" cy="386.5" r="1.5" fill="#d4af37" />
          <circle cx="228" cy="386.5" r="1.5" fill="#d4af37" />
          {/* Shine effect */}
          <path d="M 210 375 Q 215 378 220 375" stroke="white" strokeWidth="1.5" opacity="0.4" />
        </g>
      );
    } else if (outfit.shoes === 'heels') {
      return (
        <g id="heels">
          <defs>
            <linearGradient id="heelGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#e74c3c" stopOpacity="1" />
              <stop offset="100%" stopColor="#c0392b" stopOpacity="1" />
            </linearGradient>
          </defs>
          {/* Left heel */}
          <ellipse cx="180" cy="405" rx="15" ry="5" fill="url(#heelGradient)" />
          <path d="M 165 405 L 170 395 L 190 395 L 195 405" fill="url(#heelGradient)" />
          <rect x="177" y="405" width="6" height="15" fill="#a93226" />
          {/* Glossy shine */}
          <ellipse cx="180" cy="398" rx="8" ry="3" fill="white" opacity="0.6" />
          
          {/* Right heel */}
          <ellipse cx="220" cy="405" rx="15" ry="5" fill="url(#heelGradient)" />
          <path d="M 205 405 L 210 395 L 230 395 L 235 405" fill="url(#heelGradient)" />
          <rect x="217" y="405" width="6" height="15" fill="#a93226" />
          {/* Glossy shine */}
          <ellipse cx="220" cy="398" rx="8" ry="3" fill="white" opacity="0.6" />
        </g>
      );
    }
    return null;
  };

  const renderAccessories = () => {
    return (
      <g id="accessories">
        {outfit.accessories.includes('necklace') && (
          <g id="necklace">
            <defs>
              <radialGradient id="gemGradient">
                <stop offset="0%" stopColor="#e74c3c" stopOpacity="1" />
                <stop offset="100%" stopColor="#c0392b" stopOpacity="0.8" />
              </radialGradient>
            </defs>
            {/* Chain */}
            <path d="M 175 165 Q 200 170 225 165" stroke="#d4af37" strokeWidth="2" fill="none" />
            {/* Chain links detail */}
            <circle cx="185" cy="166" r="1.5" fill="#d4af37" />
            <circle cx="200" cy="170" r="1.5" fill="#d4af37" />
            <circle cx="215" cy="166" r="1.5" fill="#d4af37" />
            {/* Pendant */}
            <circle cx="200" cy="180" r="6" fill="url(#gemGradient)" />
            {/* Gem facets */}
            <path d="M 197 177 L 200 180 L 203 177" stroke="white" strokeWidth="0.5" opacity="0.7" />
            <circle cx="200" cy="178" r="1.5" fill="white" opacity="0.4" />
          </g>
        )}
        {outfit.accessories.includes('hat') && (
          <g id="hat">
            <defs>
              <linearGradient id="hatGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#34495e" stopOpacity="1" />
                <stop offset="100%" stopColor="#2c3e50" stopOpacity="0.9" />
              </linearGradient>
            </defs>
            {/* Brim */}
            <ellipse cx="200" cy="45" rx="70" ry="12" fill="url(#hatGradient)" />
            {/* Crown */}
            <path d="M 150 45 L 160 20 L 240 20 L 250 45 Z" fill="url(#hatGradient)" />
            {/* Brim shadow */}
            <ellipse cx="200" cy="47" rx="65" ry="8" fill="#1a252f" opacity="0.3" />
            {/* Hat band */}
            <rect x="155" y="40" width="90" height="6" fill="#8e44ad" />
          </g>
        )}
        {outfit.accessories.includes('bag') && (
          <g id="bag">
            <defs>
              <linearGradient id="bagGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#8b4513" stopOpacity="0.9" />
                <stop offset="50%" stopColor="#a0522d" stopOpacity="1" />
                <stop offset="100%" stopColor="#8b4513" stopOpacity="0.9" />
              </linearGradient>
            </defs>
            {/* Strap */}
            <path d="M 115 230 Q 100 270 105 310" stroke="#654321" strokeWidth="5" fill="none" />
            {/* Bag body */}
            <rect x="85" y="310" width="45" height="55" rx="4" fill="url(#bagGradient)" />
            {/* Flap */}
            <path d="M 85 310 L 83 300 L 132 300 L 130 310 Z" fill="#a0522d" />
            {/* Buckle */}
            <rect x="104" y="303" width="8" height="5" rx="1" fill="#d4af37" />
            <rect x="106" y="304" width="4" height="3" fill="#654321" />
            {/* Stitching */}
            <rect x="87" y="315" width="41" height="1" fill="#654321" opacity="0.5" />
            <rect x="87" y="360" width="41" height="1" fill="#654321" opacity="0.5" />
            {/* Texture lines */}
            <line x1="90" y1="320" x2="90" y2="360" stroke="#654321" strokeWidth="0.5" opacity="0.3" />
            <line x1="107" y1="320" x2="107" y2="360" stroke="#654321" strokeWidth="0.5" opacity="0.3" />
            <line x1="124" y1="320" x2="124" y2="360" stroke="#654321" strokeWidth="0.5" opacity="0.3" />
          </g>
        )}
      </g>
    );
  };

  return (
    <svg width="400" height="500" viewBox="0 0 400 500" xmlns="http://www.w3.org/2000/svg">
      <defs>
        {/* Skin gradients */}
        <radialGradient id="faceGradient">
          <stop offset="0%" stopColor={skin.highlight} />
          <stop offset="100%" stopColor={skin.base} />
        </radialGradient>
        <linearGradient id="neckGradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor={skin.shadow} />
          <stop offset="50%" stopColor={skin.base} />
          <stop offset="100%" stopColor={skin.shadow} />
        </linearGradient>
      </defs>

      {/* Background */}
      <rect width="400" height="500" fill="#f8f9fa" />

      {/* Avatar */}
      <g id="avatar">
        {/* Neck */}
        <rect x="185" y="150" width="30" height="35" fill="url(#neckGradient)" />
        
        {/* Body/Arms base (before clothing) */}
        <g id="arms">
          <defs>
            <linearGradient id="armGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={skin.base} />
              <stop offset="50%" stopColor={skin.shadow} />
              <stop offset="100%" stopColor={skin.base} />
            </linearGradient>
          </defs>
          {/* Left arm */}
          <rect x="110" y="200" width="20" height="100" rx="10" fill="url(#armGradient)" />
          <ellipse cx="120" cy="300" rx="12" ry="15" fill={skin.base} />
          {/* Elbow definition */}
          <line x1="110" y1="250" x2="130" y2="250" stroke={skin.shadow} strokeWidth="1" opacity="0.3" />
          
          {/* Right arm */}
          <rect x="270" y="200" width="20" height="100" rx="10" fill="url(#armGradient)" />
          <ellipse cx="280" cy="300" rx="12" ry="15" fill={skin.base} />
          {/* Elbow definition */}
          <line x1="270" y1="250" x2="290" y2="250" stroke={skin.shadow} strokeWidth="1" opacity="0.3" />
        </g>

        {/* Clothing */}
        {renderTop()}
        {renderBottom()}
        {renderShoes()}

        {/* Head */}
        <ellipse cx="200" cy="110" rx="65" ry="75" fill="url(#faceGradient)" />
        
        {/* Ears */}
        <ellipse cx="135" cy="110" rx="12" ry="18" fill={skin.base} />
        <ellipse cx="265" cy="110" rx="12" ry="18" fill={skin.base} />
        <ellipse cx="137" cy="110" rx="6" ry="10" fill={skin.shadow} />
        <ellipse cx="263" cy="110" rx="6" ry="10" fill={skin.shadow} />

        {/* Face features */}
        <g id="face">
          {/* Eyebrows */}
          <path d="M 165 90 Q 175 88 185 90" stroke="#4a4a4a" strokeWidth="3" fill="none" strokeLinecap="round" />
          <path d="M 215 90 Q 225 88 235 90" stroke="#4a4a4a" strokeWidth="3" fill="none" strokeLinecap="round" />
          
          {/* Eyes */}
          <ellipse cx="175" cy="105" rx="12" ry="15" fill="white" />
          <ellipse cx="225" cy="105" rx="12" ry="15" fill="white" />
          
          {/* Irises */}
          <circle cx="175" cy="107" r="7" fill="#4a90e2" />
          <circle cx="225" cy="107" r="7" fill="#4a90e2" />
          
          {/* Pupils */}
          <circle cx="175" cy="107" r="4" fill="#1a1a1a" />
          <circle cx="225" cy="107" r="4" fill="#1a1a1a" />
          
          {/* Eye highlights */}
          <circle cx="177" cy="105" r="2" fill="white" />
          <circle cx="227" cy="105" r="2" fill="white" />
          
          {/* Eyelids */}
          <path d="M 163 105 Q 175 102 187 105" stroke="#4a4a4a" strokeWidth="1.5" fill="none" />
          <path d="M 213 105 Q 225 102 237 105" stroke="#4a4a4a" strokeWidth="1.5" fill="none" />
          
          {/* Nose */}
          <path d="M 200 105 L 200 125" stroke={skin.shadow} strokeWidth="2" fill="none" />
          <path d="M 195 125 Q 200 128 205 125" stroke={skin.shadow} strokeWidth="1.5" fill="none" />
          {/* Nostrils */}
          <ellipse cx="196" cy="126" rx="2" ry="3" fill={skin.shadow} opacity="0.5" />
          <ellipse cx="204" cy="126" rx="2" ry="3" fill={skin.shadow} opacity="0.5" />
          
          {/* Mouth */}
          <path d="M 185 140 Q 200 148 215 140" stroke="#c0392b" strokeWidth="2" fill="none" strokeLinecap="round" />
          {/* Lips detail */}
          <path d="M 185 140 Q 200 143 215 140" fill="#e74c3c" opacity="0.6" />
          <path d="M 185 140 Q 200 145 215 140" stroke="#a93226" strokeWidth="0.5" />
          
          {/* Cheeks (blush) */}
          <ellipse cx="155" cy="120" rx="15" ry="10" fill="#ffb3ba" opacity="0.4" />
          <ellipse cx="245" cy="120" rx="15" ry="10" fill="#ffb3ba" opacity="0.4" />
        </g>

        {/* Hair - rendered on top */}
        {renderHair()}

        {/* Accessories - rendered on top */}
        {renderAccessories()}
      </g>
    </svg>
  );
}
