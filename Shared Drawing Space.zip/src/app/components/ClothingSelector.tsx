import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { Shirt, Glasses, Footprints, ShoppingBag } from 'lucide-react';

interface ClothingSelectorProps {
  outfit: {
    top: string;
    bottom: string;
    shoes: string;
    accessories: string[];
  };
  onOutfitChange: (outfit: any) => void;
}

export function ClothingSelector({ outfit, onOutfitChange }: ClothingSelectorProps) {
  const tops = ['t-shirt', 'hoodie', 'dress'];
  const bottoms = ['jeans', 'skirt', 'shorts'];
  const shoes = ['sneakers', 'boots', 'heels'];
  const accessories = ['necklace', 'hat', 'bag'];

  const toggleAccessory = (accessory: string) => {
    const newAccessories = outfit.accessories.includes(accessory)
      ? outfit.accessories.filter((a) => a !== accessory)
      : [...outfit.accessories, accessory];
    onOutfitChange({ ...outfit, accessories: newAccessories });
  };

  return (
    <div className="space-y-6">
      {/* Tops */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Shirt className="w-5 h-5" />
          <Label className="text-lg font-semibold">Tops</Label>
        </div>
        <div className="flex gap-2 flex-wrap">
          {tops.map((top) => (
            <Button
              key={top}
              variant={outfit.top === top ? 'default' : 'outline'}
              size="sm"
              onClick={() => onOutfitChange({ ...outfit, top })}
              className="capitalize"
            >
              {top}
            </Button>
          ))}
        </div>
      </Card>

      {/* Bottoms */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Glasses className="w-5 h-5" />
          <Label className="text-lg font-semibold">Bottoms</Label>
        </div>
        <div className="flex gap-2 flex-wrap">
          {bottoms.map((bottom) => (
            <Button
              key={bottom}
              variant={outfit.bottom === bottom ? 'default' : 'outline'}
              size="sm"
              onClick={() => onOutfitChange({ ...outfit, bottom })}
              className="capitalize"
            >
              {bottom}
            </Button>
          ))}
        </div>
      </Card>

      {/* Shoes */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Footprints className="w-5 h-5" />
          <Label className="text-lg font-semibold">Shoes</Label>
        </div>
        <div className="flex gap-2 flex-wrap">
          {shoes.map((shoe) => (
            <Button
              key={shoe}
              variant={outfit.shoes === shoe ? 'default' : 'outline'}
              size="sm"
              onClick={() => onOutfitChange({ ...outfit, shoes: shoe })}
              className="capitalize"
            >
              {shoe}
            </Button>
          ))}
        </div>
      </Card>

      {/* Accessories */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <ShoppingBag className="w-5 h-5" />
          <Label className="text-lg font-semibold">Accessories</Label>
        </div>
        <div className="flex gap-2 flex-wrap">
          {accessories.map((accessory) => (
            <Button
              key={accessory}
              variant={outfit.accessories.includes(accessory) ? 'default' : 'outline'}
              size="sm"
              onClick={() => toggleAccessory(accessory)}
              className="capitalize"
            >
              {accessory}
            </Button>
          ))}
        </div>
      </Card>
    </div>
  );
}
