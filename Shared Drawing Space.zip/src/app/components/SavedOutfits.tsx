import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Heart, Trash2 } from 'lucide-react';
import { RealisticAvatar } from './RealisticAvatar';

interface SavedOutfit {
  id: string;
  name: string;
  skinTone: string;
  hairColor: string;
  hairStyle: string;
  outfit: {
    top: string;
    bottom: string;
    shoes: string;
    accessories: string[];
  };
}

interface SavedOutfitsProps {
  outfits: SavedOutfit[];
  onLoad: (outfit: SavedOutfit) => void;
  onDelete: (id: string) => void;
}

export function SavedOutfits({ outfits, onLoad, onDelete }: SavedOutfitsProps) {
  if (outfits.length === 0) {
    return (
      <Card className="p-8 text-center">
        <Heart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">No saved outfits yet.</p>
        <p className="text-sm text-gray-500 mt-2">
          Create your perfect look and save it for later!
        </p>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {outfits.map((savedOutfit) => (
        <Card key={savedOutfit.id} className="p-4 hover:shadow-lg transition-shadow">
          <div className="flex justify-between items-start mb-2">
            <h4 className="font-semibold text-sm truncate">{savedOutfit.name}</h4>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(savedOutfit.id)}
              className="h-8 w-8 p-0"
            >
              <Trash2 className="w-4 h-4 text-red-600" />
            </Button>
          </div>
          <div className="bg-gray-50 rounded-lg p-2 mb-3 flex items-center justify-center">
            <div className="scale-50 origin-center">
              <RealisticAvatar
                skinTone={savedOutfit.skinTone}
                hairColor={savedOutfit.hairColor}
                hairStyle={savedOutfit.hairStyle}
                outfit={savedOutfit.outfit}
              />
            </div>
          </div>
          <Button size="sm" className="w-full" onClick={() => onLoad(savedOutfit)}>
            Load Outfit
          </Button>
        </Card>
      ))}
    </div>
  );
}
