import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Sparkles, Sun, Briefcase, Zap } from 'lucide-react';

interface AIStyleGuidanceProps {
  onApplyStyle: (style: any) => void;
}

export function AIStyleGuidance({ onApplyStyle }: AIStyleGuidanceProps) {
  const stylePresets = [
    {
      name: 'Summer Casual',
      icon: Sun,
      description: 'Light and breezy for warm days',
      outfit: {
        top: 't-shirt',
        bottom: 'shorts',
        shoes: 'sneakers',
        accessories: [],
      },
    },
    {
      name: 'Professional Chic',
      icon: Briefcase,
      description: 'Polished look for the office',
      outfit: {
        top: 'dress',
        bottom: 'jeans',
        shoes: 'heels',
        accessories: ['necklace', 'bag'],
      },
    },
    {
      name: 'Street Style',
      icon: Zap,
      description: 'Urban cool with edge',
      outfit: {
        top: 'hoodie',
        bottom: 'jeans',
        shoes: 'sneakers',
        accessories: ['hat'],
      },
    },
    {
      name: 'Evening Elegance',
      icon: Sparkles,
      description: 'Sophisticated and glamorous',
      outfit: {
        top: 'dress',
        bottom: 'skirt',
        shoes: 'heels',
        accessories: ['necklace', 'bag'],
      },
    },
  ];

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-6 h-6 text-purple-600" />
        <h3 className="text-xl font-bold">AI Design Guidance</h3>
      </div>
      <p className="text-sm text-gray-600 mb-6">
        Get curated style suggestions based on the latest trends
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {stylePresets.map((preset) => {
          const Icon = preset.icon;
          return (
            <Card key={preset.name} className="p-4 hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-base">{preset.name}</h4>
                  <p className="text-xs text-gray-600">{preset.description}</p>
                </div>
              </div>
              <Button
                size="sm"
                className="w-full"
                onClick={() => onApplyStyle(preset.outfit)}
              >
                Apply Style
              </Button>
            </Card>
          );
        })}
      </div>
    </Card>
  );
}
