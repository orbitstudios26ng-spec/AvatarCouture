import React from 'react';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Palette, User } from 'lucide-react';

interface AvatarCustomizerProps {
  skinTone: string;
  hairColor: string;
  hairStyle: string;
  onSkinToneChange: (tone: string) => void;
  onHairColorChange: (color: string) => void;
  onHairStyleChange: (style: string) => void;
}

export function AvatarCustomizer({
  skinTone,
  hairColor,
  hairStyle,
  onSkinToneChange,
  onHairColorChange,
  onHairStyleChange,
}: AvatarCustomizerProps) {
  const skinTones = [
    { name: 'light', color: '#ffd6c8' },
    { name: 'medium', color: '#d4a373' },
    { name: 'tan', color: '#c68b59' },
    { name: 'dark', color: '#8b5a3c' },
    { name: 'deep', color: '#5c3d2e' },
  ];

  const hairColors = [
    { name: 'black', color: '#1a1a1a' },
    { name: 'brown', color: '#5c4033' },
    { name: 'blonde', color: '#f4d03f' },
    { name: 'red', color: '#c23b22' },
    { name: 'gray', color: '#95a5a6' },
  ];

  const hairStyles = ['short', 'long', 'curly'];

  return (
    <div className="space-y-6">
      {/* Skin Tone */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <User className="w-5 h-5" />
          <Label className="text-lg font-semibold">Skin Tone</Label>
        </div>
        <div className="flex gap-2 flex-wrap">
          {skinTones.map((tone) => (
            <button
              key={tone.name}
              onClick={() => onSkinToneChange(tone.name)}
              className={`w-12 h-12 rounded-full border-2 transition-all ${
                skinTone === tone.name ? 'border-primary scale-110' : 'border-gray-300'
              }`}
              style={{ backgroundColor: tone.color }}
              title={tone.name}
            />
          ))}
        </div>
      </Card>

      {/* Hair Color */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Palette className="w-5 h-5" />
          <Label className="text-lg font-semibold">Hair Color</Label>
        </div>
        <div className="flex gap-2 flex-wrap">
          {hairColors.map((color) => (
            <button
              key={color.name}
              onClick={() => onHairColorChange(color.name)}
              className={`w-12 h-12 rounded-full border-2 transition-all ${
                hairColor === color.name ? 'border-primary scale-110' : 'border-gray-300'
              }`}
              style={{ backgroundColor: color.color }}
              title={color.name}
            />
          ))}
        </div>
      </Card>

      {/* Hair Style */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Palette className="w-5 h-5" />
          <Label className="text-lg font-semibold">Hair Style</Label>
        </div>
        <div className="flex gap-2 flex-wrap">
          {hairStyles.map((style) => (
            <Button
              key={style}
              variant={hairStyle === style ? 'default' : 'outline'}
              size="sm"
              onClick={() => onHairStyleChange(style)}
              className="capitalize"
            >
              {style}
            </Button>
          ))}
        </div>
      </Card>
    </div>
  );
}
