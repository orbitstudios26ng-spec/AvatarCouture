'use client';

import React, { useState } from 'react';
import { RealisticAvatar } from './components/RealisticAvatar';
import { AvatarCustomizer } from './components/AvatarCustomizer';
import { ClothingSelector } from './components/ClothingSelector';
import { AIStyleGuidance } from './components/AIStyleGuidance';
import { SavedOutfits } from './components/SavedOutfits';
import { Button } from './components/ui/button';
import { Card } from './components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './components/ui/dialog';
import { Save, Palette, Shirt, Sparkles, Heart } from 'lucide-react';
import { toast } from 'sonner';
import { Toaster } from './components/ui/sonner';

interface SavedOutfit {
  id: string;
  name: string;
  skinTone: string;
  hairColor: string;
  hairStyle: string;
  outfit: {
    top: string;
    bottom: string;
    shoes: string;
    accessories: string[];
  };
}

export default function App() {
  const [skinTone, setSkinTone] = useState('medium');
  const [hairColor, setHairColor] = useState('brown');
  const [hairStyle, setHairStyle] = useState('long');
  const [outfit, setOutfit] = useState({
    top: 't-shirt',
    bottom: 'jeans',
    shoes: 'sneakers',
    accessories: [] as string[],
  });
  const [savedOutfits, setSavedOutfits] = useState<SavedOutfit[]>([]);
  const [outfitName, setOutfitName] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleSaveOutfit = () => {
    if (!outfitName.trim()) {
      toast.error('Please enter a name for your outfit');
      return;
    }

    const newOutfit: SavedOutfit = {
      id: Date.now().toString(),
      name: outfitName,
      skinTone,
      hairColor,
      hairStyle,
      outfit,
    };

    setSavedOutfits([...savedOutfits, newOutfit]);
    setOutfitName('');
    setIsDialogOpen(false);
    toast.success('Outfit saved successfully!');
  };

  const handleLoadOutfit = (savedOutfit: SavedOutfit) => {
    setSkinTone(savedOutfit.skinTone);
    setHairColor(savedOutfit.hairColor);
    setHairStyle(savedOutfit.hairStyle);
    setOutfit(savedOutfit.outfit);
    toast.success(`Loaded "${savedOutfit.name}"`);
  };

  const handleDeleteOutfit = (id: string) => {
    setSavedOutfits(savedOutfits.filter((o) => o.id !== id));
    toast.success('Outfit deleted');
  };

  const handleApplyStyle = (styleOutfit: any) => {
    setOutfit(styleOutfit);
    toast.success('Style applied!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <Toaster />
      
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Fashion Studio
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                Create your perfect look with AI-powered style guidance
              </p>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button size="lg" className="gap-2">
                  <Save className="w-4 h-4" />
                  Save Outfit
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Save Your Outfit</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="outfit-name">Outfit Name</Label>
                    <Input
                      id="outfit-name"
                      placeholder="e.g., Summer Party Look"
                      value={outfitName}
                      onChange={(e) => setOutfitName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleSaveOutfit();
                        }
                      }}
                    />
                  </div>
                  <Button onClick={handleSaveOutfit} className="w-full">
                    Save Outfit
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Avatar Display */}
          <div className="lg:col-span-1">
            <Card className="p-6 bg-white/80 backdrop-blur-sm sticky top-24">
              <h2 className="text-xl font-semibold mb-4 text-center">Your Avatar</h2>
              <div className="flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-4">
                <RealisticAvatar
                  skinTone={skinTone}
                  hairColor={hairColor}
                  hairStyle={hairStyle}
                  outfit={outfit}
                />
              </div>
            </Card>
          </div>

          {/* Customization Panels */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="avatar" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm">
                <TabsTrigger value="avatar" className="gap-2">
                  <Palette className="w-4 h-4" />
                  Avatar
                </TabsTrigger>
                <TabsTrigger value="clothing" className="gap-2">
                  <Shirt className="w-4 h-4" />
                  Clothing
                </TabsTrigger>
                <TabsTrigger value="ai" className="gap-2">
                  <Sparkles className="w-4 h-4" />
                  AI Styles
                </TabsTrigger>
                <TabsTrigger value="saved" className="gap-2">
                  <Heart className="w-4 h-4" />
                  Saved
                </TabsTrigger>
              </TabsList>

              <TabsContent value="avatar" className="space-y-4">
                <Card className="p-6 bg-white/80 backdrop-blur-sm">
                  <h2 className="text-2xl font-bold mb-6">Customize Your Avatar</h2>
                  <AvatarCustomizer
                    skinTone={skinTone}
                    hairColor={hairColor}
                    hairStyle={hairStyle}
                    onSkinToneChange={setSkinTone}
                    onHairColorChange={setHairColor}
                    onHairStyleChange={setHairStyle}
                  />
                </Card>
              </TabsContent>

              <TabsContent value="clothing" className="space-y-4">
                <Card className="p-6 bg-white/80 backdrop-blur-sm">
                  <h2 className="text-2xl font-bold mb-6">Choose Your Outfit</h2>
                  <ClothingSelector outfit={outfit} onOutfitChange={setOutfit} />
                </Card>
              </TabsContent>

              <TabsContent value="ai" className="space-y-4">
                <div className="bg-white/80 backdrop-blur-sm rounded-lg">
                  <AIStyleGuidance onApplyStyle={handleApplyStyle} />
                </div>
              </TabsContent>

              <TabsContent value="saved" className="space-y-4">
                <Card className="p-6 bg-white/80 backdrop-blur-sm">
                  <h2 className="text-2xl font-bold mb-6">Saved Outfits</h2>
                  <SavedOutfits
                    outfits={savedOutfits}
                    onLoad={handleLoadOutfit}
                    onDelete={handleDeleteOutfit}
                  />
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white/80 backdrop-blur-sm border-t border-gray-200 mt-16">
        <div className="container mx-auto px-4 py-6 text-center">
          <p className="text-sm text-gray-600 animate-fade-in">
            © 2026 dostudios.ng. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
