
  # Shared Drawing Space

  This is a code bundle for Shared Drawing Space. The original project is available at https://www.figma.com/design/ybJGRNJIPvyIvJbSPM2fWh/Shared-Drawing-Space.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  